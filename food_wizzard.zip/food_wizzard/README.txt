{\rtf1\ansi\ansicpg1251\cocoartf2709
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 FOOD WIZARD ONLINE\
==================\
\
No installation needed! \uc0\u55356 \u57225 \
\
Just open this link in your browser:\
\uc0\u55357 \u56393  https://your-username.github.io/food-wizard/\
\
Features:\
- Background music starts after your first click.\
- Click the "CLIC CLIC CLIC" button to generate your dinner suggestion.\
- Fun sounds and pixel fonts included.\
}